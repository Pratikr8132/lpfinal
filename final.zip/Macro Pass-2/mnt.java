
public class mnt {
	String name;
	int addr;
	int arg_cnt;
	mnt(String nm, int address,int total_arg)
	{
		this.name=nm;
		this.addr=address;
		this.arg_cnt=total_arg;
	}
}