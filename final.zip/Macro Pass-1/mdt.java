


public class mdt {
String stmnt;
public mdt() {
	// TODO Auto-generated constructor stub
	stmnt="";
}
}
