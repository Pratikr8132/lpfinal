import java.lang.reflect.Array;
import java.util.*;

public class combine{



	public static void ring(){}






	public static void bully(){}






	public static void main(String[] args) {
	
	Scanner sc = new Scanner(System.in);
        System.out.print("which one u want 1.ring 2.bully ");
        int a=sc.nextInt();
        switch (a) {
    		case 1: 
    			ring();
    			break;
    		case 2: 
    			bully();
    			break;
    		    }
    
    
    
    
    
    }
    }
