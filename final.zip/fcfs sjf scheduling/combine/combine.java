import java.io.*;
import java.util.Scanner;


public class combine{

	

	
	public static void SRTF(){ 
	
	Scanner sc=new Scanner(System.in);
	
System.out.println ("enter no of process:");
int n= sc.nextInt();
int pid[] = new int[n]; // it takes pid of process
int at[] = new int[n]; // at means arrival time
int bt[] = new int[n]; // bt means burst time
int ct[] = new int[n]; // ct means complete time
int ta[] = new int[n];// ta means turn around time
int wt[] = new int[n];  // wt means waiting time
int f[] = new int[n];  // f means it is flag it checks process is completed or not
int k[]= new int[n];   // it is also stores brust time
    int i, st=0, tot=0;
    float avgwt=0, avgta=0;
 
    for (i=0;i<n;i++)
    {
     pid[i]= i+1;
     System.out.println ("enter process " +(i+1)+ " arrival time:");
     at[i]= sc.nextInt();
     System.out.println("enter process " +(i+1)+ " burst time:");
     bt[i]= sc.nextInt();
     k[i]= bt[i];
     f[i]= 0;
    }
    
    while(true){
     int min=99,c=n;
     if (tot==n)
     break;
    
     for ( i=0;i<n;i++)
     {
     if ((at[i]<=st) && (f[i]==0) && (bt[i]<min))
     {
     min=bt[i];
     c=i;
     }
     }
    
     if (c==n)
     st++;
     else
     {
     bt[c]--;
     st++;
     if (bt[c]==0)
     {
     ct[c]= st;
     f[c]=1;
     tot++;
     }
     }
    }
    
    for(i=0;i<n;i++)
    {
     ta[i] = ct[i] - at[i];
     wt[i] = ta[i] - k[i];
     avgwt+= wt[i];
     avgta+= ta[i];
    }
    
    System.out.println("pid  arrival  burst  complete turn waiting");
    for(i=0;i<n;i++)
    {
     System.out.println(pid[i] +"\t"+ at[i]+"\t"+ k[i] +"\t"+ ct[i] +"\t"+ ta[i] +"\t"+ wt[i]);
    }
    
    System.out.println("\naverage tat is "+ (float)(avgta/n));
    System.out.println("average wt is "+ (float)(avgwt/n));
    sc.close();
	
	}









	public static void FCFS(){
	
	Scanner sc = new Scanner(System.in);
        System.out.print("Enter No of Processes: ");
        int t_process = sc.nextInt();
        int[] PID = new int[t_process];
        int[] AT = new int[t_process];
        int[] BT = new int[t_process];
        int[] CT = new int[t_process];
        int[] TAT = new int[t_process];
        int[] WT = new int[t_process];
        float ATAT = 0,AWT=0;
        System.out.println("Enter PID AT BT of  Processes");
        System.out.println("PID AT BT ");
        for (int i = 0; i < t_process; i++) {
            PID[i] = sc.nextInt();
            AT[i] = sc.nextInt();
            BT[i] = sc.nextInt();
        }

        for (int i = 0; i < t_process-1; i++) {
            for (int j = 0; j < t_process - i - 1; j++) {
                if (AT[j] > AT[j + 1])
                {
                    int temp = AT[j];
                    AT[j] = AT[j + 1];
                    AT[j + 1] = temp;

                    int temp1 = PID[j];
                    PID[j] = PID[j + 1];
                    PID[j + 1] = temp1;

                    int temp2 = BT[j];
                    BT[j] = BT[j + 1];
                    BT[j + 1] = temp2;
                }
            }
        }
        System.out.println("PID AT BT ");
        for (int i = 0; i < t_process; i++) {
            System.out.println(" "+PID[i]+"\t"+AT[i]+"\t"+BT[i]+" ");
        }

        for (int i = 0; i < t_process; i++) {
            if(i==0){
                CT[i] = AT[i] + BT[i];
            }else {
                if(AT[i] > CT[i-1]){
                    CT[i] = AT[i] + BT[i];
                }else {
                    CT[i] = BT[i] + CT[i-1];
                }
            }
            TAT[i] = CT[i] - AT[i];
            WT[i] = TAT[i] - BT[i];
            ATAT+=TAT[i];
            AWT+=WT[i];
        }
        System.out.println("PID AT  BT  CT  TAT WT");
        for (int i = 0; i < t_process; i++) {
            System.out.println(" "+PID[i]+"\t"+AT[i]+"\t"+BT[i]+"\t"+CT[i]+"\t"+TAT[i]+"\t"+WT[i]);
        }
        System.out.println("Average TAT is: "+(ATAT/t_process)+"\n"+"Average WT is: "+(AWT/t_process));

	
	
	}








	public static void main(String args[]) throws IOException{
	
	Scanner sc = new Scanner(System.in);
        System.out.print("which one u want 1.FCFS 2.SRTF ");
        int KL=sc.nextInt();
        switch (KL) {
    		case 1: 
    			FCFS();
    			break;
    		case 2: 
    			SRTF();
    			break;
    		    }
    
    
    
    
    
    }
    }
